package logica;

import java.util.ArrayList;
import modelo.*;

/** Administra productos, clientes y ventas durante la ejecucion. */
public class GestorPapeleria {
    private ArrayList<Producto> productos;
    private ArrayList<Cliente> clientes;
    private ArrayList<Venta> ventas;
    private int minimoExistencias = 3;

    /** Inicializa las listas y los datos de ejemplo. */
    public GestorPapeleria() {
        productos = new ArrayList<Producto>();
        clientes = new ArrayList<Cliente>();
        ventas = new ArrayList<Venta>();
        cargarDatos();
    }

    private void cargarDatos() {
        productos.add(new ProductoUnidad("P001", "Cuaderno", 6500, 20));
        productos.add(new ProductoUnidad("P002", "Lapiz", 1500, 40));
        productos.add(new ProductoUnidad("P003", "Borrador", 1000, 15));
        productos.add(new ProductoPaquete("P004", "Colores x12", 12000, 10));
        productos.add(new ProductoPaquete("P005", "Marcadores x6", 9000, 8));
        clientes.add(new Cliente("1001", "Cliente de ejemplo Ana"));
        clientes.add(new Cliente("1002", "Cliente de ejemplo Luis"));
    }

    public ArrayList<Producto> getProductos() { return productos; }
    public ArrayList<Cliente> getClientes() { return clientes; }
    public ArrayList<Venta> getVentas() { return ventas; }

    public Producto buscarProducto(String codigo) {
        for (Producto p : productos) if (p.getCodigo().equalsIgnoreCase(codigo)) return p;
        return null;
    }
    public Cliente buscarCliente(String documento) {
        for (Cliente c : clientes) if (c.getDocumento().equals(documento)) return c;
        return null;
    }
    public boolean agregarProducto(Producto p) {
        if (buscarProducto(p.getCodigo()) != null) return false;
        productos.add(p);
        return true;
    }
    public boolean agregarCliente(Cliente c) {
        if (buscarCliente(c.getDocumento()) != null) return false;
        clientes.add(c);
        return true;
    }
    public ArrayList<Producto> productosBajos() {
        ArrayList<Producto> bajos = new ArrayList<Producto>();
        for (Producto p : productos) if (p.getExistencias() < minimoExistencias) bajos.add(p);
        return bajos;
    }
    public boolean guardarVenta(Venta venta) {
        if (venta.getItems().isEmpty()) return false;
        ventas.add(venta);
        return true;
    }
}
