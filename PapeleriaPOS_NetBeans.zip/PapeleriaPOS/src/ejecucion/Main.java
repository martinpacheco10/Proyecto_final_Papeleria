package ejecucion;

import java.util.Scanner;
import modelo.*;
import logica.GestorPapeleria;

/** Punto de entrada y menu de consola del sistema Papeleria POS. */
public class Main {
    private static Scanner sc = new Scanner(System.in);
    private static GestorPapeleria gestor = new GestorPapeleria();

    /** Inicia el programa y muestra el menu principal.
     * @param args argumentos de ejecucion
     */
    public static void main(String[] args) {
        int opcion;
        do {
            System.out.println("\n===== PAPELERIA POS =====");
            System.out.println("1. Listar productos");
            System.out.println("2. Registrar producto");
            System.out.println("3. Buscar producto");
            System.out.println("4. Actualizar precio y existencias");
            System.out.println("5. Productos con inventario bajo");
            System.out.println("6. Registrar cliente");
            System.out.println("7. Listar clientes");
            System.out.println("8. Realizar venta");
            System.out.println("9. Reporte de ventas");
            System.out.println("0. Salir");
            System.out.print("Opcion: ");
            opcion = leerEntero();
            switch (opcion) {
                case 1: listarProductos(); break;
                case 2: registrarProducto(); break;
                case 3: buscarProducto(); break;
                case 4: actualizarProducto(); break;
                case 5: listarBajos(); break;
                case 6: registrarCliente(); break;
                case 7: listarClientes(); break;
                case 8: realizarVenta(); break;
                case 9: reporte(); break;
                case 0: System.out.println("Hasta pronto."); break;
                default: System.out.println("Opcion no valida.");
            }
        } while (opcion != 0);
    }

    private static int leerEntero() {
        try { int n = Integer.parseInt(sc.nextLine()); return n; }
        catch (Exception e) { return -1; }
    }
    private static double leerDouble() {
        try { return Double.parseDouble(sc.nextLine()); }
        catch (Exception e) { return -1; }
    }
    private static void listarProductos() {
        for (Producto p : gestor.getProductos()) System.out.println(p);
    }
    private static void registrarProducto() {
        System.out.print("Codigo: "); String codigo = sc.nextLine();
        System.out.print("Nombre: "); String nombre = sc.nextLine();
        System.out.print("Precio base: "); double precio = leerDouble();
        System.out.print("Existencias: "); int cantidad = leerEntero();
        if (precio < 0 || cantidad < 0) { System.out.println("Datos no validos."); return; }
        System.out.print("Tipo (1 unidad / 2 paquete): "); int tipo = leerEntero();
        Producto p;
        if (tipo == 1) p = new ProductoUnidad(codigo, nombre, precio, cantidad);
        else if (tipo == 2) p = new ProductoPaquete(codigo, nombre, precio, cantidad);
        else { System.out.println("Tipo no valido."); return; }
        System.out.println(gestor.agregarProducto(p) ? "Producto guardado." : "Ese codigo ya existe.");
    }
    private static void buscarProducto() {
        System.out.print("Codigo: "); Producto p = gestor.buscarProducto(sc.nextLine());
        System.out.println(p == null ? "Producto no encontrado." : p);
    }
    private static void actualizarProducto() {
        System.out.print("Codigo: "); Producto p = gestor.buscarProducto(sc.nextLine());
        if (p == null) { System.out.println("Producto no encontrado."); return; }
        System.out.print("Nuevo precio base: "); double precio = leerDouble();
        System.out.print("Nuevas existencias: "); int stock = leerEntero();
        if (precio < 0 || stock < 0) { System.out.println("Datos no validos."); return; }
        p.setPrecioBase(precio); p.setExistencias(stock);
        System.out.println("Producto actualizado.");
    }
    private static void listarBajos() {
        if (gestor.productosBajos().isEmpty()) System.out.println("No hay productos con inventario bajo.");
        for (Producto p : gestor.productosBajos()) System.out.println(p);
    }
    private static void registrarCliente() {
        System.out.print("Documento: "); String doc = sc.nextLine();
        System.out.print("Nombre: "); String nombre = sc.nextLine();
        System.out.println(gestor.agregarCliente(new Cliente(doc, nombre)) ? "Cliente guardado." : "Documento ya registrado.");
    }
    private static void listarClientes() {
        for (Cliente c : gestor.getClientes()) System.out.println(c);
    }
    private static void realizarVenta() {
        System.out.print("Documento del cliente (0 para cliente general): ");
        String doc = sc.nextLine();
        Cliente cliente = doc.equals("0") ? new Cliente("0", "Cliente general") : gestor.buscarCliente(doc);
        if (cliente == null) { System.out.println("Cliente no encontrado."); return; }
        Venta venta = new Venta(cliente);
        String seguir;
        do {
            System.out.print("Codigo del producto: "); Producto p = gestor.buscarProducto(sc.nextLine());
            if (p == null) { System.out.println("Producto no encontrado."); }
            else {
                System.out.print("Cantidad: "); int cantidad = leerEntero();
                if (!p.descontar(cantidad)) System.out.println("Venta rechazada: existencias insuficientes.");
                else venta.agregarItem(new ItemVenta(p, cantidad));
            }
            System.out.print("Agregar otro producto? (s/n): "); seguir = sc.nextLine();
        } while (seguir.equalsIgnoreCase("s"));
        if (venta.getItems().isEmpty()) { System.out.println("No se genero la venta."); return; }
        System.out.print("Pago (1 efectivo / 2 tarjeta): "); int pago = leerEntero();
        if (pago == 1) venta.setMedioPago(new PagoEfectivo());
        else if (pago == 2) venta.setMedioPago(new PagoTarjeta());
        else { System.out.println("Medio de pago no valido. Venta cancelada."); return; }
        gestor.guardarVenta(venta);
        imprimirRecibo(venta);
    }
    private static void imprimirRecibo(Venta v) {
        System.out.println("\n===== COMPROBANTE #" + v.getNumero() + " =====");
        System.out.println("Cliente: " + v.getCliente());
        for (ItemVenta item : v.getItems())
            System.out.println(item.getProducto().getNombre() + " x " + item.getCantidad()
                    + " = $" + item.calcularSubtotal());
        System.out.println("Subtotal: $" + v.calcularSubtotal());
        System.out.println("IVA 19%: $" + v.calcularIva());
        System.out.println("TOTAL: $" + v.calcularTotal());
        System.out.println("Pago: " + v.getMedioPago());
    }
    private static void reporte() {
        double total = 0;
        for (Venta v : gestor.getVentas()) {
            System.out.println("Venta #" + v.getNumero() + " - $" + v.calcularTotal());
            total += v.calcularTotal();
        }
        System.out.println("Cantidad de ventas: " + gestor.getVentas().size());
        System.out.println("Total vendido: $" + total);
    }
}
