package modelo;

/** Producto vendido por unidad, como un lapiz o un cuaderno. */
public class ProductoUnidad extends Producto {
    /** Crea un producto por unidad.
     * @param codigo codigo
     * @param nombre nombre
     * @param precioBase precio
     * @param existencias unidades disponibles
     */
    public ProductoUnidad(String codigo, String nombre, double precioBase, int existencias) {
        super(codigo, nombre, precioBase, existencias);
    }

    @Override
    public double calcularPrecioVenta() {
        return getPrecioBase();
    }
}
