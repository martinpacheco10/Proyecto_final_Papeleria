package modelo;

import java.util.ArrayList;

/** Agrupa los items y calcula los valores de una venta. */
public class Venta {
    private static int consecutivo = 1;
    public static final double IVA = 0.19;
    private int numero;
    private Cliente cliente;
    private ArrayList<ItemVenta> items;
    private MedioPago medioPago;

    /** Crea una venta.
     * @param cliente cliente asociado
     */
    public Venta(Cliente cliente) {
        this.numero = consecutivo++;
        this.cliente = cliente;
        this.items = new ArrayList<ItemVenta>();
    }
    public void agregarItem(ItemVenta item) { items.add(item); }
    public void setMedioPago(MedioPago medioPago) { this.medioPago = medioPago; }
    public int getNumero() { return numero; }
    public Cliente getCliente() { return cliente; }
    public ArrayList<ItemVenta> getItems() { return items; }
    public double calcularSubtotal() {
        double total = 0;
        for (ItemVenta item : items) total += item.calcularSubtotal();
        return total;
    }
    public double calcularIva() { return calcularSubtotal() * IVA; }
    public double calcularTotal() { return calcularSubtotal() + calcularIva(); }
    public String getMedioPago() { return medioPago == null ? "Sin definir" : medioPago.getNombre(); }
}
