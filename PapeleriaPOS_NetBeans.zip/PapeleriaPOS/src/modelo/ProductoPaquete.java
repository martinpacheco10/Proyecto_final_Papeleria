package modelo;

/** Producto vendido en paquete, con un descuento del 10 por ciento. */
public class ProductoPaquete extends Producto {
    /** Crea un producto por paquete.
     * @param codigo codigo
     * @param nombre nombre
     * @param precioBase precio base del paquete
     * @param existencias paquetes disponibles
     */
    public ProductoPaquete(String codigo, String nombre, double precioBase, int existencias) {
        super(codigo, nombre, precioBase, existencias);
    }

    @Override
    public double calcularPrecioVenta() {
        return getPrecioBase() * 0.90;
    }
}
