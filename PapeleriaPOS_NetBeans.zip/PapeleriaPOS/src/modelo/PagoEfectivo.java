package modelo;

/** Medio de pago en efectivo. */
public class PagoEfectivo implements MedioPago {
    @Override
    public String getNombre() { return "Efectivo"; }
}
