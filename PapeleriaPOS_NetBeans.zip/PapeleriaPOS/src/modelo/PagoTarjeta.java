package modelo;

/** Medio de pago con tarjeta. */
public class PagoTarjeta implements MedioPago {
    @Override
    public String getNombre() { return "Tarjeta"; }
}
