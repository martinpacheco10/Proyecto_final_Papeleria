package modelo;

/** Representa un producto y su cantidad dentro de una venta. */
public class ItemVenta {
    private Producto producto;
    private int cantidad;

    /** Crea un item de venta.
     * @param producto producto vendido
     * @param cantidad cantidad vendida
     */
    public ItemVenta(Producto producto, int cantidad) {
        this.producto = producto;
        this.cantidad = cantidad;
    }
    public Producto getProducto() { return producto; }
    public int getCantidad() { return cantidad; }
    public double calcularSubtotal() { return producto.calcularPrecioVenta() * cantidad; }
}
