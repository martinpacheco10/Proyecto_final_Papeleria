package modelo;

/** Guarda los datos de un cliente. */
public class Cliente {
    private String documento;
    private String nombre;

    /** Crea un cliente.
     * @param documento numero de documento
     * @param nombre nombre completo
     */
    public Cliente(String documento, String nombre) {
        this.documento = documento;
        this.nombre = nombre;
    }
    public String getDocumento() { return documento; }
    public String getNombre() { return nombre; }

    @Override
    public String toString() { return documento + " - " + nombre; }
}
