package modelo;

/** Contrato para los medios de pago del sistema. */
public interface MedioPago {
    /** Devuelve el nombre del medio de pago.
     * @return nombre del medio de pago
     */
    String getNombre();
}
