package modelo;

/** Representa un producto general de la papeleria. */
public abstract class Producto {
    private String codigo;
    private String nombre;
    private double precioBase;
    private int existencias;

    /** Crea un producto.
     * @param codigo codigo unico
     * @param nombre nombre del producto
     * @param precioBase precio base
     * @param existencias unidades disponibles
     */
    public Producto(String codigo, String nombre, double precioBase, int existencias) {
        this.codigo = codigo;
        this.nombre = nombre;
        setPrecioBase(precioBase);
        setExistencias(existencias);
    }

    /** Calcula el precio de venta segun el tipo de producto.
     * @return precio de venta
     */
    public abstract double calcularPrecioVenta();

    public String getCodigo() { return codigo; }
    public String getNombre() { return nombre; }
    public double getPrecioBase() { return precioBase; }
    public int getExistencias() { return existencias; }

    public void setPrecioBase(double precioBase) {
        if (precioBase >= 0) this.precioBase = precioBase;
    }
    public void setExistencias(int existencias) {
        if (existencias >= 0) this.existencias = existencias;
    }

    /** Descuenta unidades del inventario.
     * @param cantidad unidades a descontar
     * @return true si se pudo realizar
     */
    public boolean descontar(int cantidad) {
        if (cantidad <= 0 || cantidad > existencias) return false;
        existencias -= cantidad;
        return true;
    }

    @Override
    public String toString() {
        return codigo + " | " + nombre + " | $" + calcularPrecioVenta()
                + " | Existencias: " + existencias;
    }
}
